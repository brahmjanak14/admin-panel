import { NotFoundError } from '../../shared/errors/NotFoundError';
import { buildPaginationMeta } from '../../shared/utils/pagination';
import { toCsv } from '../../shared/utils/csvExport';
import { cacheService } from '../../shared/cache/cacheService';
import { cacheKeys, cachePatterns } from '../../shared/cache/cacheKeys';
import { leadsRepository } from './leads.repository';
import type { CreateLeadInput, Lead, LeadStatus } from './leads.types';
import type { LeadListQuery } from './leads.schema';

async function invalidateDashboardCache() {
  await cacheService.del(cacheKeys.dashboardStats());
}

export const leadsService = {
  async list(query: LeadListQuery) {
    const result = await leadsRepository.findMany(query);
    return {
      data: result.items,
      meta: buildPaginationMeta(result.total, result.page, result.perPage),
    };
  },

  async getById(id: string): Promise<Lead> {
    const lead = await leadsRepository.findById(id);
    if (!lead) throw new NotFoundError('Lead not found');
    return lead;
  },

  async updateStatus(id: string, status: LeadStatus): Promise<Lead> {
    await this.getById(id);
    const updated = await leadsRepository.updateStatus(id, status);
    await invalidateDashboardCache();
    return updated;
  },

  async createPublic(input: CreateLeadInput): Promise<Lead> {
    const lead = await leadsRepository.create(input);
    await invalidateDashboardCache();
    return lead;
  },

  async exportCsv(query: LeadListQuery): Promise<string> {
    const leads = await leadsRepository.findForExport(query);
    return toCsv(
      leads.map((l) => ({ ...l, metadata: l.metadata ? JSON.stringify(l.metadata) : undefined })),
      [
        { key: 'id', header: 'ID' },
        { key: 'type', header: 'Type' },
        { key: 'status', header: 'Status' },
        { key: 'name', header: 'Name' },
        { key: 'email', header: 'Email' },
        { key: 'phone', header: 'Phone' },
        { key: 'country', header: 'Country' },
        { key: 'service', header: 'Service' },
        { key: 'source', header: 'Source' },
        { key: 'createdAt', header: 'Created At' },
      ],
    );
  },
};

export async function invalidateLeadCaches() {
  await cacheService.invalidatePattern(cachePatterns.dashboard);
}
