import { z } from 'zod';

const leadTypeEnum = z.enum(['contact', 'consultation', 'newsletter', 'career']);
const leadStatusEnum = z.enum(['new', 'contacted', 'qualified', 'converted', 'closed']);

export const leadListQuerySchema = z.object({
  type: leadTypeEnum.optional(),
  status: leadStatusEnum.optional(),
  search: z.string().optional(),
  page: z.coerce.number().int().positive().optional(),
  perPage: z.coerce.number().int().positive().max(100).optional(),
});

export const leadIdParamSchema = z.object({
  id: z.string().uuid(),
});

export const updateLeadStatusSchema = z.object({
  status: leadStatusEnum,
});

export const createPublicLeadSchema = z.object({
  type: leadTypeEnum,
  name: z.string().min(1),
  email: z.string().email(),
  phone: z.string().optional(),
  message: z.string().optional(),
  source: z.string().optional(),
  country: z.string().optional(),
  service: z.string().optional(),
  metadata: z.record(z.string()).optional(),
});

export type LeadListQuery = z.infer<typeof leadListQuerySchema>;
